// Optional placeholder migration; Solana Playground doesn't use this script automatically.
console.log("Deploy via Solana Playground UI (Build & Deploy).");
