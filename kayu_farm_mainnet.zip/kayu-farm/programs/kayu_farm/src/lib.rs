use anchor_lang::prelude::*;
use anchor_lang::system_program::SystemAccount;
use anchor_lang::solana_program::{
    program::invoke,
    system_instruction,
    sysvar::instructions as sysvar_ix,
    ed25519_program,
    system_program,
};
use anchor_spl::token::{self, Mint, Token, TokenAccount, Transfer};

declare_id!("KAYUFarm11111111111111111111111111111111111");

// =====================================================
// ==================== 常量定义 ========================
// =====================================================
pub const BPS_DENOM: u64 = 10_000;
pub const DEFAULT_VESTING_SECS: i64 = 3 * 24 * 3600; // 3 天
pub const KAYU_DECIMALS: u64 = 1_000_000_000;        // 9 位
pub const KAYU_MINT: Pubkey = pubkey!("FjPustc7ikQnzMfDHYEs7mkZaihwoJ6kiyAiQavW3ems");

macro_rules! state_signer_seeds {
    ($s:expr) => {
        [b"state_signer", $s.key().as_ref(), &[$s.signer_bump]]
    };
}
use state_signer_seeds as _;

// =====================================================
#[account]
pub struct FarmState {
    // 基本
    pub admin: Pubkey,
    pub reward_signer: Pubkey,    // 用于签 RewardVoucher 的ed25519公钥
    pub kayu_mint: Pubkey,        // 固定为 KAYU_MINT
    pub reward_pool: Pubkey,      // KAYU 发奖池 (owner = state_signer)
    pub burn_token: Pubkey,       // KAYU 销毁账户 (owner = state_signer)
    pub sol_treasury: Pubkey,     // SOL 财库（你的钱包）
    pub instant_ratio_bps: u16,   // 即时比例
    pub vesting_ratio_bps: u16,   // 锁仓比例
    pub vesting_secs: i64,        // 锁仓时长
    pub invite_bps: [u16; 5],     // 5 层邀请比例
    pub paused: bool,
    pub signer_bump: u8,

    // 经济参数（可调，单位见注）
    pub land_unlock_fee_sol: u64,     // lamports
    pub land_unlock_fee_kayu: u64,    // KAYU原子
    pub water_fee_kayu: u64,
    pub fertilize_fee_kayu: u64,
    pub maintenance_fee_kayu: u64,

    // 作物/种子配置
    pub seed_prices: [u64; 5],        // 5 种子价格(KAYU)
    pub crop_growth_times: [i64; 5],  // 5 作物成长时间(秒)
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct FarmConfigRaw {
    pub reward_signer: Pubkey,
    pub instant_ratio_bps: u16,
    pub vesting_ratio_bps: u16,
    pub vesting_secs: i64,
    pub invite_bps: [u16; 5],
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct FarmEconomyConfig {
    pub land_unlock_fee_sol: Option<u64>,
    pub land_unlock_fee_kayu: Option<u64>,
    pub water_fee_kayu: Option<u64>,
    pub fertilize_fee_kayu: Option<u64>,
    pub maintenance_fee_kayu: Option<u64>,
    pub seed_prices: Option<[u64; 5]>,
    pub crop_growth_times: Option<[i64; 5]>,
}

#[account]
pub struct User {
    pub owner: Pubkey,
    pub inviter: Option<Pubkey>, // 没带邀请就绑定 admin
}

#[account]
pub struct Vesting {
    pub user: Pubkey,
    pub id: u64,
    pub total: u64,
    pub claimed: u64,
    pub start: i64,
    pub end: i64,
}

#[account]
pub struct NonceRecord {
    pub used: bool,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct RewardVoucher {
    pub program_id: Pubkey,
    pub user: Pubkey,
    pub amount: u64,
    pub vesting_id: u64,
    pub nonce: u64,
    pub expiry: i64,
}
impl RewardVoucher {
    pub fn message_bytes(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(32 + 32 + 8 + 8 + 8 + 8);
        v.extend_from_slice(self.program_id.as_ref());
        v.extend_from_slice(self.user.as_ref());
        v.extend_from_slice(&self.amount.to_le_bytes());
        v.extend_from_slice(&self.vesting_id.to_le_bytes());
        v.extend_from_slice(&self.nonce.to_le_bytes());
        v.extend_from_slice(&self.expiry.to_le_bytes());
        v
    }
}

// =====================================================
#[error_code]
pub enum ErrorCode {
    #[msg("Contract is paused")] Paused,
    #[msg("Self invite not allowed")] SelfInvite,
    #[msg("Invalid mint or ATA")] WrongMint,
    #[msg("Math overflow")] MathOverflow,
    #[msg("Instant + Vesting ratios must equal 10000 bps")] BadRatios,
    #[msg("Invite ratio sum exceeds 100%")] InviteTooHigh,
    #[msg("Insufficient reward pool balance")] InsufficientPool,
    #[msg("Voucher expired")] VoucherExpired,
    #[msg("Wrong program id")] WrongProgram,
    #[msg("Wrong user in voucher or claim")] WrongUser,
    #[msg("Invalid or missing Ed25519 signature instruction")] InvalidSignature,
    #[msg("Missing admin ATA at the end of remaining_accounts")] MissingAdminATA,
    #[msg("Invalid referral chain or ATA / PDA check failed")] InvalidReferralChain,
    #[msg("Zero amount")] ZeroAmount,
    #[msg("User token account not owned by payer")] WrongOwner,
    #[msg("Vesting ID mismatch")] VestingIdMismatch,
    #[msg("Inviter not found or not initialized")] InviterNotFound,
    #[msg("Invalid seed type")] InvalidSeedType,
}

#[event] pub struct Initialized { pub admin: Pubkey, pub reward_signer: Pubkey }
#[event] pub struct ConfigUpdated {}
#[event] pub struct EconomyUpdated {}
#[event] pub struct PausedEvt {}
#[event] pub struct UnpausedEvt {}
#[event] pub struct UserInited { pub user: Pubkey, pub inviter: Pubkey }
#[event] pub struct Harvested { pub user: Pubkey, pub amount: u64, pub instant: u64, pub vested: u64 }
#[event] pub struct VestingClaimed { pub user: Pubkey, pub amount: u64 }
#[event] pub struct AdminWithdraw { pub amount: u64 }

// =====================================================
#[program]
pub mod kayu_farm {
    use super::*;

    // ---------- 初始化 ----------
    pub fn initialize_farm(ctx: Context<InitializeFarm>, cfg: FarmConfigRaw) -> Result<()> {
        require!(
            cfg.instant_ratio_bps as u64 + cfg.vesting_ratio_bps as u64 == BPS_DENOM,
            ErrorCode::BadRatios
        );
        let invite_sum: u64 = cfg.invite_bps.iter().map(|x| *x as u64).sum();
        require!(invite_sum <= BPS_DENOM, ErrorCode::InviteTooHigh);

        let s = &mut ctx.accounts.state;
        s.admin = ctx.accounts.admin.key();
        s.reward_signer = cfg.reward_signer;
        s.signer_bump = *ctx.bumps.get("state_signer").unwrap();
        s.kayu_mint = ctx.accounts.kayu_mint.key();
        s.reward_pool = ctx.accounts.reward_pool.key();
        s.burn_token = ctx.accounts.burn_token.key();
        s.sol_treasury = ctx.accounts.sol_treasury.key();

        s.instant_ratio_bps = cfg.instant_ratio_bps;     // 建议传 7000
        s.vesting_ratio_bps = cfg.vesting_ratio_bps;     // 建议传 3000
        s.vesting_secs = if cfg.vesting_secs > 0 { cfg.vesting_secs } else { DEFAULT_VESTING_SECS };
        s.invite_bps = cfg.invite_bps;
        s.paused = false;

        // 默认经济参数（与你文档一致，可随时 update_economy 调整）
        s.land_unlock_fee_sol = 100_000_000;            // 0.1 SOL
        s.land_unlock_fee_kayu = 1000 * KAYU_DECIMALS;  // 1000 KAYU
        s.water_fee_kayu = 10 * KAYU_DECIMALS;
        s.fertilize_fee_kayu = 20 * KAYU_DECIMALS;
        s.maintenance_fee_kayu = 5 * KAYU_DECIMALS;

        // 种子价格与成长配置（可改）
        s.seed_prices = [600, 900, 1300, 1700, 2500].map(|v| v * KAYU_DECIMALS);
        s.crop_growth_times = [86400, 2*86400, 3*86400, 5*86400, 7*86400];

        emit!(Initialized { admin: s.admin, reward_signer: s.reward_signer });
        Ok(())
    }

    // ---------- 参数更新 ----------
    pub fn update_config(ctx: Context<AdminUpdate>, cfg: FarmConfigRaw) -> Result<()> {
        let s = &mut ctx.accounts.state;
        require_keys_eq!(s.admin, ctx.accounts.admin.key());
        require!(
            cfg.instant_ratio_bps as u64 + cfg.vesting_ratio_bps as u64 == BPS_DENOM,
            ErrorCode::BadRatios
        );
        let invite_sum: u64 = cfg.invite_bps.iter().map(|x| *x as u64).sum();
        require!(invite_sum <= BPS_DENOM, ErrorCode::InviteTooHigh);

        s.reward_signer = cfg.reward_signer;
        s.instant_ratio_bps = cfg.instant_ratio_bps;
        s.vesting_ratio_bps = cfg.vesting_ratio_bps;
        s.vesting_secs = if cfg.vesting_secs > 0 { cfg.vesting_secs } else { DEFAULT_VESTING_SECS };
        s.invite_bps = cfg.invite_bps;

        emit!(ConfigUpdated {});
        Ok(())
    }

    // ---------- 动态更新经济参数 ----------
    pub fn update_economy(ctx: Context<AdminUpdate>, cfg: FarmEconomyConfig) -> Result<()> {
        let s = &mut ctx.accounts.state;
        require_keys_eq!(s.admin, ctx.accounts.admin.key());
        if let Some(v) = cfg.land_unlock_fee_sol  { s.land_unlock_fee_sol = v; }
        if let Some(v) = cfg.land_unlock_fee_kayu { s.land_unlock_fee_kayu = v; }
        if let Some(v) = cfg.water_fee_kayu       { s.water_fee_kayu = v; }
        if let Some(v) = cfg.fertilize_fee_kayu   { s.fertilize_fee_kayu = v; }
        if let Some(v) = cfg.maintenance_fee_kayu { s.maintenance_fee_kayu = v; }
        if let Some(v) = cfg.seed_prices          { s.seed_prices = v; }
        if let Some(v) = cfg.crop_growth_times    { s.crop_growth_times = v; }
        emit!(EconomyUpdated {});
        Ok(())
    }

    // ---------- 暂停/恢复 ----------
    pub fn pause(ctx: Context<OnlyAdmin>) -> Result<()> {
        let s = &mut ctx.accounts.state;
        require_keys_eq!(s.admin, ctx.accounts.admin.key());
        s.paused = true;
        emit!(PausedEvt {});
        Ok(())
    }
    pub fn unpause(ctx: Context<OnlyAdmin>) -> Result<()> {
        let s = &mut ctx.accounts.state;
        require_keys_eq!(s.admin, ctx.accounts.admin.key());
        s.paused = false;
        emit!(UnpausedEvt {});
        Ok(())
    }

    // ---------- 管理员紧急提取（暂停与否均可） ----------
    pub fn admin_emergency_withdraw(ctx: Context<OnlyAdminWithdraw>, amount: u64) -> Result<()> {
        let s = &ctx.accounts.state;
        require_keys_eq!(s.admin, ctx.accounts.admin.key());
        let seeds = state_signer_seeds!(s);
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.reward_pool.to_account_info(),
                    to: ctx.accounts.to_account.to_account_info(),
                    authority: ctx.accounts.state_signer.to_account_info(),
                },
                &[&seeds],
            ),
            amount,
        )?;
        emit!(AdminWithdraw { amount });
        Ok(())
    }

    // ---------- 用户初始化（邀请绑定） ----------
    pub fn init_user(ctx: Context<InitUser>, inviter_opt: Option<Pubkey>) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);

        let u = &mut ctx.accounts.user;
        u.owner = ctx.accounts.owner.key();

        let final_inviter = inviter_opt.unwrap_or(s.admin);
        require!(final_inviter != u.owner, ErrorCode::SelfInvite);

        if final_inviter != s.admin {
            let (expected_user_pda, _) =
                Pubkey::find_program_address(&[b"user", final_inviter.as_ref()], ctx.program_id);
            let inviter_user_ai = ctx
                .remaining_accounts
                .iter()
                .find(|a| a.key() == &expected_user_pda)
                .ok_or(ErrorCode::InviterNotFound)?;
            let inviter_user = Account::<User>::try_from(inviter_user_ai)
                .map_err(|_| error!(ErrorCode::InviterNotFound))?;
            require_keys_eq!(inviter_user.owner, final_inviter, ErrorCode::InviterNotFound);
        }

        u.inviter = Some(final_inviter);
        emit!(UserInited { user: u.owner, inviter: final_inviter });
        Ok(())
    }

    // ---------- 付费动作 ----------
    pub fn pay_unlock_land(ctx: Context<PayUnlockLand>) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);

        // 收 SOL（进财库）
        let ix = system_instruction::transfer(
            &ctx.accounts.payer.key(),
            &ctx.accounts.sol_treasury.key(),
            s.land_unlock_fee_sol,
        );
        invoke(
            &ix,
            &[
                ctx.accounts.payer.to_account_info(),
                ctx.accounts.sol_treasury.to_account_info(),
                ctx.accounts.system_program.to_account_info(),
            ],
        )?;

        // 收 KAYU（进奖励池）
        transfer_checked_to_pool(
            s,
            &ctx.accounts.user_kayu,
            &ctx.accounts.reward_pool,
            &ctx.accounts.payer,
            &ctx.accounts.kayu_mint,
            &ctx.accounts.token_program,
            s.land_unlock_fee_kayu,
        )
    }

    // ✅ 种子购买：以 seed_type（0..4）与 quantity 计算扣款
    pub fn buy_seed(ctx: Context<BuySeed>, seed_type: u8, quantity: u64) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);
        require!(seed_type < 5, ErrorCode::InvalidSeedType);

        let price_per_seed = s.seed_prices[seed_type as usize];
        require!(price_per_seed > 0, ErrorCode::ZeroAmount);

        let total = price_per_seed
            .checked_mul(quantity)
            .ok_or(ErrorCode::MathOverflow)?;

        transfer_checked_to_pool(
            s,
            &ctx.accounts.user_kayu,
            &ctx.accounts.reward_pool,
            &ctx.accounts.payer,
            &ctx.accounts.kayu_mint,
            &ctx.accounts.token_program,
            total,
        )
    }

    pub fn water(ctx: Context<AcceleratePay>) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);
        transfer_checked_burn_like(
            s,
            &ctx.accounts.user_kayu,
            &ctx.accounts.burn_token,
            &ctx.accounts.payer,
            &ctx.accounts.kayu_mint,
            &ctx.accounts.token_program,
            s.water_fee_kayu,
        )
    }

    pub fn fertilize(ctx: Context<AcceleratePay>) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);
        transfer_checked_burn_like(
            s,
            &ctx.accounts.user_kayu,
            &ctx.accounts.burn_token,
            &ctx.accounts.payer,
            &ctx.accounts.kayu_mint,
            &ctx.accounts.token_program,
            s.fertilize_fee_kayu,
        )
    }

    pub fn pay_maintenance(ctx: Context<MaintenancePay>) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);
        transfer_checked_to_pool(
            s,
            &ctx.accounts.user_kayu,
            &ctx.accounts.reward_pool,
            &ctx.accounts.payer,
            &ctx.accounts.kayu_mint,
            &ctx.accounts.token_program,
            s.maintenance_fee_kayu,
        )
    }

    // ---------- 收获 + 锁仓 + 多级邀请（凭证验签） ----------
    pub fn harvest_with_voucher(ctx: Context<HarvestWithVoucher>, voucher: RewardVoucher) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);
        require!(voucher.amount > 0, ErrorCode::ZeroAmount);
        require!(Clock::get()?.unix_timestamp <= voucher.expiry, ErrorCode::VoucherExpired);
        require_keys_eq!(voucher.program_id, crate::ID, ErrorCode::WrongProgram);
        require_keys_eq!(voucher.user, ctx.accounts.user.owner, ErrorCode::WrongUser);

        verify_ed25519_signature(
            &ctx.accounts.instruction_sysvar,
            s.reward_signer,
            &voucher.message_bytes(),
        )?;

        // nonce 由 init PDA 保证唯一
        let nr = &mut ctx.accounts.nonce_record;
        nr.used = true;

        let instant = voucher.amount
            .checked_mul(s.instant_ratio_bps as u64).ok_or(ErrorCode::MathOverflow)?
            / BPS_DENOM;
        let vested = voucher.amount - instant;

        // 邀请分润总额（从奖励池出）
        let total_referral_bonus: u64 = s.invite_bps.iter()
            .map(|bps| voucher.amount * (*bps as u64) / BPS_DENOM)
            .sum();

        require!(
            ctx.accounts.reward_pool.amount >= instant + total_referral_bonus,
            ErrorCode::InsufficientPool
        );

        // 即时部分 → 玩家
        let seeds = state_signer_seeds!(s);
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.reward_pool.to_account_info(),
                    to: ctx.accounts.user_kayu.to_account_info(),
                    authority: ctx.accounts.state_signer.to_account_info(),
                },
                &[&seeds],
            ),
            instant,
        )?;

        // 初始化锁仓
        let v = &mut ctx.accounts.vesting;
        v.user = ctx.accounts.user.owner;
        v.id = voucher.vesting_id;
        v.total = vested;
        v.claimed = 0;
        v.start = Clock::get()?.unix_timestamp;
        v.end = v.start + s.vesting_secs;

        // 发放邀请分润
        pay_referrals_strict(&ctx, voucher.amount, &seeds)?;

        emit!(Harvested { user: v.user, amount: voucher.amount, instant, vested });
        Ok(())
    }

    // ---------- 领取锁仓 ----------
    pub fn claim_vesting(ctx: Context<ClaimVesting>, vesting_id: u64) -> Result<()> {
        let s = &ctx.accounts.state;
        require!(!s.paused, ErrorCode::Paused);

        let v = &mut ctx.accounts.vesting;
        require_keys_eq!(v.user, ctx.accounts.user_owner.key(), ErrorCode::WrongUser);
        require!(v.id == vesting_id, ErrorCode::VestingIdMismatch);

        let now = Clock::get()?.unix_timestamp;
        let total_secs = (v.end - v.start).max(1) as u64;
        let elapsed = (now - v.start).max(0) as u64;
        let vested = (v.total * elapsed / total_secs).min(v.total);
        let claimable = vested.saturating_sub(v.claimed);

        if claimable > 0 {
            require!(ctx.accounts.reward_pool.amount >= claimable, ErrorCode::InsufficientPool);
            v.claimed = v.claimed.checked_add(claimable).ok_or(ErrorCode::MathOverflow)?;
            let seeds = state_signer_seeds!(s);
            token::transfer(
                CpiContext::new_with_signer(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from: ctx.accounts.reward_pool.to_account_info(),
                        to: ctx.accounts.user_kayu.to_account_info(),
                        authority: ctx.accounts.state_signer.to_account_info(),
                    },
                    &[&seeds],
                ),
                claimable,
            )?;
            emit!(VestingClaimed { user: v.user, amount: claimable });
        }

        // 领取完毕则手动关闭账户，退还租金
        if v.claimed >= v.total {
            let vesting_ai = ctx.accounts.vesting.to_account_info();
            let dest_ai = ctx.accounts.user_owner.to_account_info();
            **dest_ai.lamports.borrow_mut() = dest_ai
                .lamports()
                .checked_add(vesting_ai.lamports())
                .ok_or(ErrorCode::MathOverflow)?;
            **vesting_ai.lamports.borrow_mut() = 0;
            vesting_ai.assign(&system_program::ID);
        }
        Ok(())
    }
}

// =====================================================
// ==================== 账户上下文 =======================
// =====================================================
#[derive(Accounts)]
pub struct InitializeFarm<'info> {
    #[account(init, payer = admin, space = 8 + 512)]
    pub state: Account<'info, FarmState>,

    /// CHECK: PDA signer
    #[account(seeds=[b"state_signer", state.key().as_ref()], bump)]
    pub state_signer: AccountInfo<'info>,

    // 固定 KAYU mint
    #[account(address = KAYU_MINT)]
    pub kayu_mint: Account<'info, Mint>,

    #[account(
        constraint = reward_pool.mint == kayu_mint.key(),
        constraint = reward_pool.owner == state_signer.key()
    )]
    pub reward_pool: Account<'info, TokenAccount>,

    #[account(
        constraint = burn_token.mint == kayu_mint.key(),
        constraint = burn_token.owner == state_signer.key()
    )]
    pub burn_token: Account<'info, TokenAccount>,

    // SystemAccount：其 owner 恒为 System Program
    #[account(mut)]
    pub sol_treasury: SystemAccount<'info>,

    #[account(mut)]
    pub admin: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AdminUpdate<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    #[account(mut)]
    pub state: Account<'info, FarmState>,
}

#[derive(Accounts)]
pub struct OnlyAdmin<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,
    #[account(mut)]
    pub admin: Signer<'info>,
}

#[derive(Accounts)]
pub struct OnlyAdminWithdraw<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,
    #[account(mut)]
    pub admin: Signer<'info>,

    /// CHECK
    #[account(seeds=[b"state_signer", state.key().as_ref()], bump=state.signer_bump)]
    pub state_signer: AccountInfo<'info>,

    #[account(mut, address = state.reward_pool)]
    pub reward_pool: Account<'info, TokenAccount>,

    #[account(mut)]
    pub to_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct InitUser<'info> {
    pub state: Account<'info, FarmState>,
    #[account(init, payer = owner, space = 8 + 64, seeds=[b"user", owner.key().as_ref()], bump)]
    pub user: Account<'info, User>,
    #[account(mut)]
    pub owner: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct PayUnlockLand<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,

    #[account(mut, address = state.sol_treasury)]
    pub sol_treasury: SystemAccount<'info>,

    #[account(
        mut,
        constraint = user_kayu.owner == payer.key() @ ErrorCode::WrongOwner,
        constraint = user_kayu.mint == kayu_mint.key() @ ErrorCode::WrongMint,
    )]
    pub user_kayu: Account<'info, TokenAccount>,

    #[account(mut, address = state.reward_pool)]
    pub reward_pool: Account<'info, TokenAccount>,

    #[account(address = KAYU_MINT)]
    pub kayu_mint: Account<'info, Mint>,

    #[account(mut)]
    pub payer: Signer<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct BuySeed<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,

    #[account(
        mut,
        constraint = user_kayu.owner == payer.key() @ ErrorCode::WrongOwner,
        constraint = user_kayu.mint == kayu_mint.key() @ ErrorCode::WrongMint,
    )]
    pub user_kayu: Account<'info, TokenAccount>,

    #[account(mut, address = state.reward_pool)]
    pub reward_pool: Account<'info, TokenAccount>,

    #[account(address = KAYU_MINT)]
    pub kayu_mint: Account<'info, Mint>,

    #[account(mut)]
    pub payer: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct AcceleratePay<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,

    #[account(
        mut,
        constraint = user_kayu.owner == payer.key() @ ErrorCode::WrongOwner,
        constraint = user_kayu.mint == kayu_mint.key() @ ErrorCode::WrongMint,
    )]
    pub user_kayu: Account<'info, TokenAccount>,

    #[account(mut, address = state.burn_token)]
    pub burn_token: Account<'info, TokenAccount>,

    #[account(address = KAYU_MINT)]
    pub kayu_mint: Account<'info, Mint>,

    #[account(mut)]
    pub payer: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct MaintenancePay<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,

    #[account(
        mut,
        constraint = user_kayu.owner == payer.key() @ ErrorCode::WrongOwner,
        constraint = user_kayu.mint == kayu_mint.key() @ ErrorCode::WrongMint,
    )]
    pub user_kayu: Account<'info, TokenAccount>,

    #[account(mut, address = state.reward_pool)]
    pub reward_pool: Account<'info, TokenAccount>,

    #[account(address = KAYU_MINT)]
    pub kayu_mint: Account<'info, Mint>,

    #[account(mut)]
    pub payer: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
#[instruction(voucher: RewardVoucher)]
pub struct HarvestWithVoucher<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,

    /// CHECK
    #[account(seeds=[b"state_signer", state.key().as_ref()], bump=state.signer_bump)]
    pub state_signer: AccountInfo<'info>,

    #[account(mut, address = state.reward_pool)]
    pub reward_pool: Account<'info, TokenAccount>,

    #[account(mut, seeds=[b"user", user_owner.key().as_ref()], bump)]
    pub user: Account<'info, User>,

    #[account(
        init,
        payer = payer,
        space = 8 + 80,
        seeds=[b"vesting", user.owner.as_ref(), &voucher.vesting_id.to_le_bytes()],
        bump
    )]
    pub vesting: Account<'info, Vesting>,

    #[account(
        init,
        payer = payer,
        space = 8 + 8,
        seeds=[b"nonce", user.owner.as_ref(), &voucher.nonce.to_le_bytes()],
        bump
    )]
    pub nonce_record: Account<'info, NonceRecord>,

    #[account(
        mut,
        constraint = user_kayu.mint == kayu_mint.key() @ ErrorCode::WrongMint,
        constraint = user_kayu.owner == user_owner.key() @ ErrorCode::WrongOwner,
    )]
    pub user_kayu: Account<'info, TokenAccount>,

    #[account(address = user.owner)]
    pub user_owner: Signer<'info>,

    #[account(address = KAYU_MINT)]
    pub kayu_mint: Account<'info, Mint>,

    /// CHECK: sysvar instructions
    #[account(address = sysvar_ix::ID)]
    pub instruction_sysvar: AccountInfo<'info>,

    #[account(mut)]
    pub payer: Signer<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(vesting_id: u64)]
pub struct ClaimVesting<'info> {
    #[account(mut)]
    pub state: Account<'info, FarmState>,

    /// CHECK
    #[account(seeds=[b"state_signer", state.key().as_ref()], bump=state.signer_bump)]
    pub state_signer: AccountInfo<'info>,

    #[account(mut, address = state.reward_pool)]
    pub reward_pool: Account<'info, TokenAccount>,

    #[account(
        mut,
        seeds=[b"vesting", user_owner.key().as_ref(), &vesting_id.to_le_bytes()],
        bump
    )]
    pub vesting: Account<'info, Vesting>,

    #[account(
        mut,
        constraint = user_kayu.mint == kayu_mint.key() @ ErrorCode::WrongMint,
        constraint = user_kayu.owner == user_owner.key() @ ErrorCode::WrongOwner,
    )]
    pub user_kayu: Account<'info, TokenAccount>,

    #[account(mut)]
    pub user_owner: Signer<'info>,

    #[account(address = KAYU_MINT)]
    pub kayu_mint: Account<'info, Mint>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

// =====================================================
// ==================== 工具函数 =========================
// =====================================================
fn transfer_checked_to_pool(
    state: &FarmState,
    from_ata: &Account<TokenAccount>,
    pool_ata: &Account<TokenAccount>,
    authority: &Signer,
    mint: &Account<Mint>,
    token_program: &Program<Token>,
    amount: u64,
) -> Result<()> {
    require_keys_eq!(from_ata.mint, state.kayu_mint, ErrorCode::WrongMint);
    require_keys_eq!(pool_ata.mint, state.kayu_mint, ErrorCode::WrongMint);
    require_keys_eq!(mint.key(), state.kayu_mint, ErrorCode::WrongMint);
    token::transfer(
        CpiContext::new(
            token_program.to_account_info(),
            Transfer {
                from: from_ata.to_account_info(),
                to: pool_ata.to_account_info(),
                authority: authority.to_account_info(),
            },
        ),
        amount,
    )
}

fn transfer_checked_burn_like(
    state: &FarmState,
    from_ata: &Account<TokenAccount>,
    burn_ata: &Account<TokenAccount>,
    authority: &Signer,
    mint: &Account<Mint>,
    token_program: &Program<Token>,
    amount: u64,
) -> Result<()> {
    require_keys_eq!(from_ata.mint, state.kayu_mint, ErrorCode::WrongMint);
    require_keys_eq!(burn_ata.mint, state.kayu_mint, ErrorCode::WrongMint);
    require_keys_eq!(mint.key(), state.kayu_mint, ErrorCode::WrongMint);
    token::transfer(
        CpiContext::new(
            token_program.to_account_info(),
            Transfer {
                from: from_ata.to_account_info(),
                to: burn_ata.to_account_info(),
                authority: authority.to_account_info(),
            },
        ),
        amount,
    )
}

/// 分润：remaining_accounts 需按层提供 `(User PDA, 该 User 的 KAYU ATA)`；
/// 缺层或校验失败时回退到最后一个提供的管理员 ATA。
fn pay_referrals_strict(
    ctx: &Context<HarvestWithVoucher>,
    base: u64,
    state_seeds: &[&[u8]],
) -> Result<()> {
    let s = &ctx.accounts.state;
    let rem = &ctx.remaining_accounts;

    require!(rem.len() >= 2, ErrorCode::MissingAdminATA);
    let admin_ata_ai = rem.last().unwrap();
    let admin_ata = Account::<TokenAccount>::try_from(admin_ata_ai)
        .map_err(|_| error!(ErrorCode::InvalidReferralChain))?;
    require_keys_eq!(admin_ata.owner, s.admin, ErrorCode::InvalidReferralChain);
    require_keys_eq!(admin_ata.mint, s.kayu_mint, ErrorCode::WrongMint);

    let mut current_inviter = ctx.accounts.user.inviter;
    let mut idx = 0usize;

    for level in 0..5 {
        let bps = s.invite_bps[level] as u64;
        let bonus = base * bps / BPS_DENOM;
        if bonus == 0 { continue; } // 不递增索引

        let to_ai = if rem.len() >= (idx + 2) && current_inviter.is_some() {
            let user_ai = &rem[idx];
            let ata_ai  = &rem[idx + 1];

            let user_acct = Account::<User>::try_from(user_ai)
                .map_err(|_| error!(ErrorCode::InvalidReferralChain))?;

            // 验证 User PDA seeds 是否合法
            let (expected_user_pda, _) =
                Pubkey::find_program_address(&[b"user", user_acct.owner.as_ref()], ctx.program_id);
            require_keys_eq!(expected_user_pda, user_ai.key(), ErrorCode::InvalidReferralChain);

            if let Some(expected_inviter) = current_inviter {
                require_keys_eq!(user_acct.owner, expected_inviter, ErrorCode::InvalidReferralChain);
            }

            let ata = Account::<TokenAccount>::try_from(ata_ai)
                .map_err(|_| error!(ErrorCode::InvalidReferralChain))?;
            require_keys_eq!(ata.mint, s.kayu_mint, ErrorCode::WrongMint);
            require_keys_eq!(ata.owner, user_acct.owner, ErrorCode::InvalidReferralChain);

            current_inviter = user_acct.inviter;
            idx += 2; // 仅在使用时递增
            ata_ai.clone()
        } else {
            admin_ata_ai.clone()
        };

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.reward_pool.to_account_info(),
                    to: to_ai,
                    authority: ctx.accounts.state_signer.to_account_info(),
                },
                &[state_seeds],
            ),
            bonus,
        )?;
    }
    Ok(())
}

// =====================================================
// ==================== Ed25519 验签 ====================
// =====================================================
fn verify_ed25519_signature(
    ix_sysvar: &AccountInfo,
    signer_pubkey: Pubkey,
    message: &[u8],
) -> Result<()> {
    let ix_count = sysvar_ix::load_current_index_checked(ix_sysvar)? as usize;
    for i in 0..=ix_count {
        if let Ok(ix) = sysvar_ix::load_instruction_at_checked(i, ix_sysvar) {
            if ix.program_id == ed25519_program::id() {
                let data = ix.data;
                if data.len() == 98 + message.len()
                    && data[0] == 1  // num_signatures
                    && data[1] == 0  // padding
                    && u16::from_le_bytes([data[14], data[15]]) == 0    // signature_offset
                    && u16::from_le_bytes([data[16], data[17]]) == 98   // message_offset
                    && Pubkey::new(&data[2..34]) == signer_pubkey       // pubkey
                    && &data[98..] == message                            // message
                {
                    return Ok(());
                }
            }
        }
    }
    Err(error!(ErrorCode::InvalidSignature))
}
